/*:
## App Exercise - Workout or Nil

 >These exercises reinforce Swift concepts in the context of a fitness tracking app.

 Have you ever accidentally tapped a button in an app? It's fairly common. In your fitness tracking app, you decide that if a user accidentally taps a button to start a workout and then ends the workout within 10 seconds, you simply don't want to create and log the workout. Otherwise the user would have to go delete the workout from the log.

 Create a `Workout` struct that has properties `startTime` and `endTime` of type `Double`. Dates are difficult to work with, so you'll be using doubles to represent the number of seconds since midnight, i.e. 28800 would represent 28,800 seconds, which is exactly 8 hours, so the start time is 8am.

 Write a failable initializer that takes parameters for your start and end times, and then checks to see if they are fewer than 10 seconds apart. If they are, your initializer should fail. Otherwise, they should set the properties accordingly.
 */
struct WorkOut {
    var startTime : Double?
    var endTime : Double?
     
    init?(startTime: Double, endTime: Double){
        if (endTime - startTime) > 10{
            self.endTime = endTime
            self.startTime = startTime
        }
        else{
            return nil
        }
    }
}

//:  Try to initialize two instances of a `Workout` object. Unwrap each of them and print its properties. One of them should not be initialized because the start and end times are too close together. The other should successfully initialize a `Workout` object.
let workOutOne = WorkOut(startTime: 0, endTime: 8000)
let workOutTwo = WorkOut(startTime: 0, endTime: 10)
if let successCheckForWorkOutOne = workOutOne {
    print("Goal is set successfully!")
}else{
    print("Recheck the entered values")
}
if let successCheckForWorkOutOne = workOutTwo {
    print("Goal is set successfully!")
}else{
    print("Recheck the entered values")
}

/*:
[Previous](@previous)  |  page 6 of 6
 */
