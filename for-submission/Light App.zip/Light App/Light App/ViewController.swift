//
//  ViewController.swift
//  Light App
//
//  Created by Javeria on 23/12/2021.
//

import UIKit

class ViewController: UIViewController {
    var lightOn = true
   
    @IBOutlet weak var switchButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    fileprivate func switchingLightFunction() {
        view.backgroundColor = lightOn ? .white : .black
//        if lightOn {
//            view.backgroundColor = .white
////            switchButton.setTitle("Switch Off", for: .normal)
//        }
//        else {
//            view.backgroundColor = .black
////            switchButton.setTitle("Switch On", for: .normal)
//        }
    }
    
    @IBAction func switchButtonPressed(_ sender: Any) {
        lightOn.toggle()
        switchingLightFunction()
    }
    
}

