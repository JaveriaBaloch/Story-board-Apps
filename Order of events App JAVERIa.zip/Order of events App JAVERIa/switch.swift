//
//  switch.swift
//  Order of events App JAVERIa
//
//  Created by Javeria on 27/01/2022.
//

import Foundation
var screenSwitched = false
var displayTime = 0
