//
//  database.swift
//  Pizza Delivery App Javeria
//
//  Created by Javeria on 03/02/2022.
//

import Foundation
let chickenPizzaPrice = 1.2
let afghaniPizzaPrice = 2.2
let cheesePizzaPrice = 1.5
let vegetablePizzaPrice = 1.7
var totalPrice = Double()
