//
//  BackUp.swift
//  Alram App Javeria
//
//  Created by Javeria on 03/02/2022.
//

import Foundation
var date = DateFormatter()
var displayDate = String()
var hourDigits = String()
var minutesDigits = String()
